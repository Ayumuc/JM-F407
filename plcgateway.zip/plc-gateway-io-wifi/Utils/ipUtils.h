#ifndef _IPUTILS_H_
#define _IPUTILS_H_

int strToIpv4(char* str);

#endif
