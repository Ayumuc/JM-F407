#ifndef _CPUID_H_
#define _CPUID_H_

unsigned int* readCpuId(void);

#endif
