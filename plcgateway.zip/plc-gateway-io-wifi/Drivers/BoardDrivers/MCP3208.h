/*
 * MCP3208.h
 *
 *  Created on: Sep 23, 2021
 *      Author: Administrator
 */

#ifndef BOARDDRIVERS_MCP3208_H_
#define BOARDDRIVERS_MCP3208_H_




void initMCP(void);
int mcpSample(unsigned char chx);
void delay(unsigned int num);


#endif /* BOARDDRIVERS_MCP3208_H_ */
